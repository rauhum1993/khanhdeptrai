package binary_file;

public class Test {
    public static void main(String[] args) {
        System.out.println("Duong dan file: "+args[0]);
    }
}
